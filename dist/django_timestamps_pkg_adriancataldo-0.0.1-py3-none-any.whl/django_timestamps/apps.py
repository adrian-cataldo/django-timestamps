from django.apps import AppConfig


class DjangoTimestampsConfig(AppConfig):
    name = 'django_timestamps'
